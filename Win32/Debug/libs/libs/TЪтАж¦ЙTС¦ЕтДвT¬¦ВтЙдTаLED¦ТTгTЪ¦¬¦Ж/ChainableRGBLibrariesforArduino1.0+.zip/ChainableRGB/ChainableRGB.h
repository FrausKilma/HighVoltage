//  This header file is part of Chainable RGB LED library based on the tm1804 timing 
//  Author:CATALEX(www.catalex.taobao.com)
//  Date:19 Oct,2013
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2.1 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
/*****************************************************************************/
#ifndef _CHAINABLE_RGB_H_
#define _CHAINABLE_RGB_H_

#include <inttypes.h>
#include <Arduino.h>

class ChainableRGB
{
  public:
    void begin(uint8_t pin);
	void reset();
	void sendRGB(unsigned char red,unsigned char green,unsigned char blue);
  private:
    volatile uint8_t *tm1804_di_port;
    uint8_t tm1804_di_bitnum;
    inline void tm1804DiLow()  { *tm1804_di_port &= ~tm1804_di_bitnum; }
    inline void tm1804DiHigh() { *tm1804_di_port |= tm1804_di_bitnum; }
    void sendBit(unsigned char _bit);
};

#endif