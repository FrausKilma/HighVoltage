//  This file is part of Chainable RGB LED library based on the tm1804 timing 
//  Author:CATALEX(www.catalex.taobao.com)
//  Date:19 Oct,2013
//  Note:The frequency of the CPU(F_CPU) must be 16MHz so that the timing of 
//       controling the tm1804 IC is correct.
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2.1 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
/*****************************************************************************/

#include "ChainableRGB.h"

void ChainableRGB::begin(unsigned char pin) 
{
  pinMode(pin,OUTPUT);
  tm1804_di_bitnum = digitalPinToBitMask(pin);
  unsigned char port = digitalPinToPort(pin);
  tm1804_di_port = portOutputRegister(port);
  tm1804DiLow();
}

void ChainableRGB::sendBit(unsigned char _bit)
{
	if(_bit == 0x80)//send "1"
	{
	  tm1804DiHigh();//HIGH
	  asm("nop");//1
	  asm("nop");//2
	  asm("nop");//3
	  asm("nop");//4
	  asm("nop");//5
	  asm("nop");//6
	  asm("nop");//7
	  asm("nop");//8
	  asm("nop");//9
	  asm("nop");//10
	  asm("nop");//11
	  asm("nop");//12
	  asm("nop");//13
	  asm("nop");//14
	  asm("nop");//15
	  asm("nop");//16
	  asm("nop");//17
	  
	  tm1804DiLow();//LOW

	}
	else//_bit = 0x00,and send "0"
	{
	  tm1804DiHigh();//HIGH
	  
	  tm1804DiLow();//LOW
	  asm("nop");
	  asm("nop");
	  asm("nop");
	  asm("nop");
	  asm("nop");
	  asm("nop");
	  asm("nop");
	  asm("nop");
	  asm("nop");
	  asm("nop");
	  asm("nop");
	  asm("nop");
	  asm("nop");
	  asm("nop");
	  asm("nop");
	  asm("nop");
	  asm("nop");
	}
}

/*Function: Send RGB(the duty cycle) to tm1804   */
/*Parameters: red:0~255                          */
/*            green:0~255                        */
/*            blue:0~255                         */
/*Note: the greater the value,the brighter the LED*/
void ChainableRGB::sendRGB(unsigned char red,unsigned char green,unsigned char blue)
{
  unsigned char i;
  for(i = 8;i >0;i--)
  {
    sendBit(red & 0x80);
	red <<= 1;
  }
  for(i = 8;i >0;i--)
  {
    sendBit(green & 0x80);
	green <<= 1;
  }
  for(i = 8;i >0;i--)
  {
    sendBit(blue & 0x80);
	blue <<= 1;
  }
}

/*Send reset code to the driver IC(TM1804)*/
void ChainableRGB::reset()
{
  tm1804DiLow();
  delayMicroseconds(24);
}
/*The End*/
